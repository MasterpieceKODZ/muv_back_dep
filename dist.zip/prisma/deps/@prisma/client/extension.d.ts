export * from './scripts/default-index'
